const base_member_api = 'http://localhost:5000/member';
export default base_member_api;
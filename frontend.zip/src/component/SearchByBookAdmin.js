import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { toast } from 'react-toastify';
import { Button, Card, CardBody, Col, Container, Form, FormGroup, Input, Label, ListGroup, Row } from 'reactstrap';
import base_url from '../service/api';
import MemberMenu from './MemberMenu';
import ShowBook from './MemberShowBookCard';
import Book from './AdminShowBookCard';
import HeaderAdm from './HeaderAdm';
import Menu from './Menu';
export default function SearchByBookAdmin() {
    const { id } = useParams();
    console.log("my id output " + id)
    const [name, setName] = useState('');
    const [books, setBooks] = useState([]);

    useEffect(() => {
        document.body.style.backgroundColor = 'aliceblue';
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(name);
        console.log(name.name);
        getBooksFromServer();
    }

    const getBooksFromServer = () => {
        axios.get(`${base_url}/getbybook/${name.name}`).then(
            (response) => {
                setBooks(response.data);
            },
            (error) => {
                console.log(error);
            }
        )
    }

    const updateList = (bookId) => {
        setBooks(books.filter((b) => b.bookId != bookId));
      };

    return (
        <><HeaderAdm></HeaderAdm>
        <div style={{ marginTop: '15px' }}>
            <Row>
            <Col md={4}><Menu/></Col>
                <Col>
                    <Card style={{ marginTop: '15px', backgroundColor: 'aquamarine' }}>
                        <CardBody>
                            <Form onSubmit={handleSubmit}>
                                <FormGroup>
                                    <Label for="name">Book Name</Label>
                                    <Input
                                        type='text'
                                        placeholder='Enter book name'
                                        name='name'
                                        id='name'
                                        onChange={(e) => {
                                            setName({ ...name, name: e.target.value })
                                        }}
                                    />
                                </FormGroup>
                                <Container className='text-center'>
                                    <Button type='submit' color='primary'>
                                        Search
                                    </Button>
                                </Container>
                            </Form>
                        </CardBody>
                    </Card>
                    <div class="container-fluid">
                        <div className="d-flex flex-wrap bd-highlight mb-3">
                            {books.length > 0
                                ? books.map((book) => (
                                    <Book key={book.bookId} book={book} update={updateList} />
                                ))
                                : "No Books"}
                        </div>
                    </div>
                </Col>
            </Row>
        </div>
        </>
    )
}

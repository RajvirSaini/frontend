import axios from 'axios';
import React, { Fragment, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Card, CardBody, CardText, Col, ListGroup, Row } from 'reactstrap';
import base_member_api from '../service/member_api';
import Menu from './Menu';
import MenuList from './MenuList';
import Header from "./Header";
import '../css/background.css';


export default function MemberMenu() {
  const [member, setMember] = useState([]);
  const [userId, setUserId] = useState([]);
  const [selectedProfilePicture, setSelectedProfilePicture] = useState(null);


  const { id } = useParams()
  console.log(id);

  useEffect(() => {
    document.body.style.backgroundColor = "aliceblue"
    getMember();

  }, [])

  const getMember = async () => {
    const result = axios.get(`${base_member_api}/getmemberbyusername/${id}`).then(
      (response) => {
        console.log(response.data)
        setMember(response.data)
        setUserId(response.data)
      }, (error) => {
        console.log(error);
      }
    )

  }
  // const handleProfilePictureChange = (event) => {
  //   const file = event.target.files[0];
  //   if (file) {
  //     const reader = new FileReader();
  //     reader.onloadend = () => {
  //       setSelectedProfilePicture(reader.result);
  //     };
  //     reader.readAsDataURL(file);
  //   }
  // };



  return (
    <div>

      <Header></Header>


      <Row>
        <Col md={4}>
          <ListGroup >

            <Link className='list-group-item list-group-item-action' to={`/viewbooksformember/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>View Books</Link>
            <Link className='list-group-item list-group-item-action' to={`/issuelist/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Issue List</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbycategory/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Category</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbybook/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Book</Link>

          </ListGroup>

        </Col>

        <Col>
      
          
          {
          
          member.map(user => (
            
            <section class="vh-100" style={{"background-color": ""}}>
              <div class="container py-5 h-10">
                <div class="row d-flex justify-content-center align-items-center h-300">
                  <div class="col col-lg-10 mb-4 mb-lg-0">
                    <div class="card mb-3" style={{"border-radius": ".7rem"}}>
                      <div class="row g-0">
                    
                        <div class="col-md-4 gradient-custom text-center text-white"
                          style={{"border-top-left-radius": ".5rem", "border-bottom-left-radius":" .10rem;"}}>
                          <img src="images2\images.png"
                          
                            alt="Avatar" class="img-fluid my-5" style={{"width": "100px"}} />
                          
                          
                          <h1 > {user.username} </h1>
                          <p>Member</p>
                          <i class="far fa-edit mb-5"></i>
                        </div>
                        <div class="col-md-8">
                          <div class="card-body p-4">
                            <h3>Information</h3>
                            <hr class="mt-0 mb-4"/>
                            <div class="row pt-1">
                              <div class="col-10 mb-2">
                                <h6  >Email</h6>
                  
                                <p class="text-muted" ><span style={{"color":"blue"}}>{user.email}</span></p>
                              </div>
                              <div class="col-10 mb-3">
                                <h6>Phone</h6>
                                <p class="text-muted">{user.contact}</p>
                              </div>
                            </div>
                            {/* <h6>Projects</h6> */}
                            {/* <hr class="mt-0 mb-4"/> */}
                            <div class="row pt-1">
                              <div class="col-6 mb-3">
                                <h6 >FirstName</h6>
                                <p class="text-muted">{user.firstName}</p>
                              </div>
                              
                              <div class="col-6 mb-3">
                                <h6>LastName</h6>
                                <p class="text-muted">{user.lastName}</p>
                              </div>
                              <div class="col-6 mb-3">
                                <h6>User Id</h6>
                                <p class="text-muted">{user.memberId}</p>
                              </div>
                            </div>

                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            
            </section>
             )
             )
             }
            
                       
              



           
      </Col>
      </Row>
    </div>
  )
}

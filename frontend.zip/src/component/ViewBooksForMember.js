import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom'
import { Button, Card, CardBody, CardText, Col, Container, ListGroup, Row } from 'reactstrap';
import base_url from '../service/api';
import IssueList from './IssueList';
import ShowBook from './MemberShowBookCard';
import Header from './Header';

export default function ViewBooksForMember() {

  const navigate = useNavigate()
  const { id } = useParams();

  const [books, setBooks] = useState([]);

  useEffect(() => {
    getBooks();

    document.body.style.backgroundColor = "aliceblue"

  }, []);


  const getBooks = async () => {
    axios.get(`${base_url}/getbooks`).then(
      (response) => {
        console.log(response.data);
        setBooks(response.data);




      }, (error) => {
        console.log(error);
      }
    )

  }


  return (
    <>
    <Header></Header>
      <Row>
      <Col md={4}>
          <ListGroup >

            <Link className='list-group-item list-group-item-action' to={`/viewbooksformember/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>View Books</Link>
            <Link className='list-group-item list-group-item-action' to={`/issuelist/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Issue List</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbycategory/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Category</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbybook/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Book</Link>

          </ListGroup>

        </Col>
        <Col>
          <div class="container-fluid">
            <div className="d-flex flex-wrap bd-highlight mb-3">
              {
                books.length > 0 ? books.map((book) => (
                  <ShowBook key={book.bookId} book={book} memberUsername={id} />


                )) : "No Books"}
            </div>
          </div>

        </Col>
      </Row>

    </>
  )
}




/**
 * 
 *   {
           books.map(book =>(
           
            
            <Card className='text-center' style={{backgroundColor : 'aqua', marginBottom : '20px'}}>
              <h3>{id}</h3>
               <CardBody>
                <h4 key={book.id}> {book.name}</h4>
                 <CardText>Book Id : {book.bookId}</CardText>
                 <CardText>ISBN No : {book.isbnNo}</CardText>
                 <CardText>Author : {book.author}</CardText>

                <CardText>Publisher : {book.publisher}</CardText>
                 <CardText>Category : {book.category}</CardText>
                 <CardText>Published Date : {book.publishedDate}</CardText>

                 <Container>
                  <Button color='primary' onClick={handleClick}> Borrow</Button>
                 </Container>
               </CardBody>
          
            </Card>
           ))



         }
 */
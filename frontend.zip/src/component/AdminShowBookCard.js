import { Card, CardBody, CardTitle, CardSubtitle, CardText, Container, Button, Row, Col } from "reactstrap";
import axios from "axios";
import base_url from "../service/api";
import React, { useEffect, useState } from 'react'
import { toast } from "react-toastify";
import { Link } from "react-router-dom";
import Menu from './Menu';
import styled from 'styled-components';
import HeaderAdm from "./HeaderAdm";

const Img = styled.img`
  width: 200px;
  height: 300px;
`;

export default function AdminShowBookCard({ book, update }) {

  useEffect(() => {
    document.body.style.backgroundColor = "aliceblue"


  }, [])

  //Delete Book

  const deleteBook = (bookId) => {
    axios.delete(`${base_url}/deletebook/${bookId}`).then(
      (response) => {
        toast.success("Book Deleted Successfully", {
          position: 'bottom-center',
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark'
        })
        update(bookId);
      }, (error) => {
        toast.error("Something went wrong", {
          position: 'bottom-center',
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark'
        });
      }
    )
  }


  return (

    <div className="row">
      <div className="col-md-4">
        <div className="card mb-4 custom-card">
          <Img
            src={`/images/${book.bookId}.jpeg`}
            className="card-img-top"
            alt={book.bookId}
          />
          <div className="card-body">
            <h5 className="card-title">{book.name}</h5>
            <p className="card-text">Author: {book.author}</p>
            <Button color="danger" onClick={() => {
              deleteBook(book.bookId);
            }}>
              Delete
            </Button>
            <Link tag="a" to={`/update-book/${book.bookId}`} className='ms-2' action>
              <Button>Update</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
    




  )
}

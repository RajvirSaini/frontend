import React from 'react'
import { Link } from 'react-router-dom'
import { Container, ListGroup, ListGroupItem } from 'reactstrap'
import HeaderAdm from './HeaderAdm'

export default function menu() {
  return (
    <>
      <Container>
   <div style={{marginTop : '15px'}}>
    
       <ListGroup >
        <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action' tag="a" to='/view-books' action>View All Books</Link>
        <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action' tag="a" to = '/add-book' action>Add Book</Link>
        <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action'  tag="a" to='/adminIssuedbooks' action>Issued Books List</Link>
        <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action'  tag="a" to='/issuedforusers' action>Issued For User</Link>
        {/* <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action'  tag="a" to='/contact' action>Contact</Link> */}
        <Link style={{backgroundColor : '#404040',marginBottom : '2px', color: 'white'}} className='list-group-item list-group-item-action'  tag="a" to='/searchbybookadmin' action>Search By Book</Link>
    </ListGroup>
    
   </div>
   </Container>
   </> 
  )
}

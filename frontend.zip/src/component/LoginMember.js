import axios from 'axios'
import React, { useState, useRef, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { Button, Card, CardBody, CardFooter, Col, Container, Form, FormGroup, Input, Row } from 'reactstrap'
import base_member_api from '../service/member_api'
import '../css/background.css'
import '../css/main.css'
import '../css/util.css'
import '../css/animate.css'


export const LoginMember = () => {
    const navigate = useNavigate();

    const [login, setLogin] = useState({
        username: '',
        password: '',
        rememberMe: false, // Initialize the "rememberMe" state
    });

    const customCheckboxRef = useRef(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Access the "rememberMe" value using the ref
        login.rememberMe = customCheckboxRef.current.checked;
        sendDataToUser(login);
    };

    useEffect(() => {
        // Check for the "Remember Me" cookie when the login page loads
        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
            const [name, value] = cookie.trim().split('=');
            if (name === 'userLoginDetails') {
                const loginDetails = JSON.parse(decodeURIComponent(value));
                // Prevent displaying "Login Successful" toast on auto-login
                navigate(`/membermenu/${loginDetails.username}`);
                // toast.info("Remembered You", {
                //     position: 'bottom-right',
                //     autoClose: 2000,
                //     hideProgressBar: false,
                //     closeOnClick: true,
                //     pauseOnHover: false,
                //     theme: 'dark'
                // });
                return; // Exit the loop
            }
        }
    }, []);

    const sendDataToUser = (login) => {
        // Include the "rememberMe" value in the login data
        login.rememberMe = customCheckboxRef.current.checked;

        axios.post(`${base_member_api}/login`, login).then(
            (response) => {
                toast.success("Login Successful", {
                    position: 'bottom-right',
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    theme: 'dark'
                });

                // Store user login details in a cookie if "Remember Me" is checked
                if (login.rememberMe) {
                    const userLoginDetails = JSON.stringify(login);
                    // Set a cookie with an expiration time
                    const expirationTime = new Date().getTime() + 20000; // 7 Seconds
                    document.cookie = `userLoginDetails=${userLoginDetails}; expires=${new Date(expirationTime)}; path=/`;
                }

                navigate(`/membermenu/${login?.username}`);
            }, (error) => {
                toast.error("Invalid Username or Password", {
                    position: 'bottom-right',
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    theme: 'dark'
                });
            }
        );
    };


    return <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form" onSubmit={handleSubmit}>
                    <span class="login100-form-title p-b-43">
                        <h1>Library Management System</h1>
                        <br />
                        Login to continue
                    </span>


                    <div className="wrap-input100 validate-input" data-validate="First Name is required">
                        <input
                            className="input100"
                            type="text"
                            name="username"
                            placeholder='Username'
                            onChange={(e) => {
                                setLogin({ ...login, username: e.target.value })
                            }}
                            required
                        />
                        <span className="focus-input100"></span>
                    </div>

                    <div className="wrap-input100 validate-input" data-validate="First Name is required">
                        <input
                            className="input100"
                            type="password"
                            name="password"
                            placeholder='Password'
                            onChange={(e) => {
                                setLogin({ ...login, password: e.target.value })
                            }}
                            required
                        />
                        <span className="focus-input100"></span>
                    </div>

                    <div class="flex-sb-m w-full p-t-3 p-b-32">
                        <div className="custom-checkbox-container">
                            <input
                                ref={customCheckboxRef}
                                className="custom-checkbox-input"
                                id="customCkb1"
                                type="checkbox"
                                name="custom-remember-me"
                            />
                            <label className="custom-checkbox-label" htmlFor="customCkb1">
                                Remember me
                            </label>
                        </div>


                        <div>
                            <a href="Signup" class="txt1">Signup</a>

                        </div>
                    </div>


                    <div className="container-login100-form-btn">
                        <button className="login100-form-btn" type="submit">
                            Login
                        </button>
                    </div>

                    <div class="text-center p-t-46 p-b-20">
                        <span class="txt2">
                            Are you an <a href="login" class="txt3">Admin </a>?
                        </span>
                    </div>


                </form>

                {/* <div className="login100-more" style={{ backgroundImage: "url('images/aawq.jpg')" }}></div> */}
                <div class="login100-more" style={{ "backgroundImage": "url('images2/aawq.jpg')" }}>

                </div>
            </div>
        </div>
    </div>
}

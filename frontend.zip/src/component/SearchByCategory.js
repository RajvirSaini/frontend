import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Card, CardBody, Col, Container, Form, FormGroup, Input, Label, ListGroup, Row } from 'reactstrap';
import Header from './Header';


function SearchByCategory() {
  const { id } = useParams();
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch('http://localhost:5000/book/categories');
        if (response.ok) {
          const data = await response.json();
          setCategories(data);
        } else {
          console.error('Failed to fetch book categories');
        }
      } catch (error) {
        console.error('An error occurred while fetching book categories:', error);
      }
    }

    fetchCategories();
  }, []);

  return (
    <div style={{ marginTop: '15px' }}>
      <Header></Header>
      <Row>
      <Col md={4}>
          <ListGroup >

            <Link className='list-group-item list-group-item-action' to={`/viewbooksformember/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>View Books</Link>
            <Link className='list-group-item list-group-item-action' to={`/issuelist/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Issue List</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbycategory/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Category</Link>
            <Link className='list-group-item list-group-item-action' to={`/searchbybook/${id}`} style={{ backgroundColor: '#404040', color: 'white' }}>Search By Book</Link>

          </ListGroup>

        </Col>
        <Col>
          <div className="category-buttons">
            <div class="container-fluid">
              <style>
                {`
                  .category-button {
                  margin: 10px;
                  }
                `}
              </style>
              <div className="d-flex flex-wrap bd-highlight mb-3">
                {categories.map((category, index) => (
                  <Link to={`/category/${category}/${id}`} key={category}>
                    <div className="category-button">
                      <a>
                        <img
                          src={`/icons/${index + 1}.png`}
                          alt={`Category ${category}`}
                        />
                      </a>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default SearchByCategory;

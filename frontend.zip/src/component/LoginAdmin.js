import axios from 'axios'
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { Button, Card, CardBody, CardFooter, Col, Container, Form, FormGroup, Input, Row } from 'reactstrap'
import base_member_api from '../service/member_api'
import '../css/background.css'

export default function LoginAdmin() {

    const navigate = useNavigate()

    const [admin, setAdmin] = useState({
        username: '',
        password: '',
    })

    const handleSubmit = (e) => {
        e.preventDefault();
        sendAdminToUser(admin);
        console.log(admin);
    }



    const sendAdminToUser = (admin) => {


        axios.post(`${base_member_api}/adminlogin`, admin).then(
            (response) => {
                toast.success("Login Sucessfull", {
                    position: 'bottom-right',
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    theme: 'dark'
                })
                navigate('/home');
            }, (error) => {
                toast.error("Wrong Username or password", {
                    position: 'bottom-right',
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    theme: 'dark'
                })
            }
        )
    }


    return (

        <div className="limiter">
            <div className="container-login100">
                <div className="wrap-login100">
                    <form className="login100-form validate-form" onSubmit={handleSubmit}>
                        <span className="login100-form-title p-b-43">
                            <h1>Library Management System</h1>
                            <br />
                            Admin Login to continue
                        </span>

                        <div className="wrap-input100 validate-input" data-validate="First Name is required">
                            <input
                                className="input100"
                                type="text"
                                name="adminUserName"
                                id='username'
                                onChange={(e) => {
                                    setAdmin({ ...admin, username: e.target.value });
                                }}
                                required
                            />
                            <span className="focus-input100"></span>
                            <span className="label-input100">Admin Username</span>
                        </div>

                        <div className="wrap-input100 validate-input" data-validate="First Name is required">
                            <input
                                className="input100"
                                type="password"
                                name="password"
                                id='password'
                                onChange={(e) => {
                                    setAdmin({ ...admin, password: e.target.value });
                                }}
                                required
                            />
                            <span className="focus-input100"></span>
                            <span className="label-input100">Admin Password</span>
                        </div>

                        <div className="container-login100-form-btn">
                            <button className="login100-form-btn" type="submit">
                                Login
                            </button>
                        </div>

                        <div className="text-center p-t-46 p-b-20">
                            <span className="txt2">
                                Are you a <a href="/" className="txt3">Member</a>?
                            </span>
                        </div>
                    </form>

                    <div className="login100-more" style={{ backgroundImage: "url('images2/XZ.jpg')" }}></div>
                </div>
            </div>
        </div>
    )
}

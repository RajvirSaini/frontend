import React, { useState } from 'react';
import '../css/header.css';
/* import DropdownMenu from './DropdownMenu'; */
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import { useParams } from 'react-router-dom';

const gravatarSrc = '/images2/header_icon.webp';

const HeaderAdm = () => {
  const [showDropdown, setShowDropdown] = useState(false);

  const { id } = useParams()

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const handleLogout = () => {
    // Clear the "userLoginDetails" cookie
    document.cookie = 'userLoginDetails=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/';

    window.location.href = '/'; 
  };

  return (
    <div className="header-container">
      <div className="header-content">
        <img className="avatar" src={gravatarSrc} alt="Avatar" />
        <h2>Library Management System</h2>
        <nav className="nav-items">
          <DropdownButton id="dropdown-basic-button" title={<img src={'../images2/images.jpg'} alt="Profile" className="avatar" style={{ marginLeft: "20px" }} />}>
            <Dropdown.Item href="/"
              onClick={handleLogout}>
              Logout
              </Dropdown.Item>
          </DropdownButton>



        </nav>
      </div>
    </div>
  );
};

export default HeaderAdm;

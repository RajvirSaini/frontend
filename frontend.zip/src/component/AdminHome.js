import React, { useEffect } from "react";
import { Container, Button, Row, Col } from "reactstrap";
import Menu from './Menu';
import HeaderAdm from "./HeaderAdm";



export default function AdminHome() {
  useEffect(() => {

    document.title = "Home"
  }, []);


  return (
    <div>
      <HeaderAdm /> 
      <Row>
        <Col md={4}><Menu /></Col>
        <Col>
          <div className="mt-4 p-5 bg-light text-dark rounded text-center">
            <p>Welcome to the Library Management System.</p>
          </div>
        </Col>
      </Row>
    </div>
  );
}



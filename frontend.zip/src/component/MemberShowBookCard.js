import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Button, Card, CardBody, CardText, Container } from 'reactstrap';
import issue_book_url from '../service/IssueUrl';
import '../App.css';
import styled from 'styled-components';

const Img = styled.img`
  width: 200px;
  height: 300px;
`;

export default function MemberShowBookCard({ book, memberUsername }) {
  const navigate = useNavigate();

  // Function to get the current date in the format YYYY-MM-DD
  const getCurrentDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Function to calculate the return date (30 days from the issue date)
  const calculateReturnDate = (issueDate) => {
    const returnDate = new Date(issueDate);
    returnDate.setDate(returnDate.getDate() + 30);
    return returnDate.toISOString().split('T')[0];
  };

  const [issue, setIssue] = useState({
    memberUsername: memberUsername,
    bookId: book.bookId,
    issueDate: getCurrentDate(), // Get the current date
    returnDate: calculateReturnDate(getCurrentDate()), // Calculate the return date
  });

  const handleClick = (bookid) => {
    setIssue({ ...issue, bookId: bookid });
    sendIssueDetailsToUser(issue);
    navigate(`/membermenu/${memberUsername}`);
  };

  const sendIssueDetailsToUser = (data) => {
    axios.post(`${issue_book_url}/borrowBook`, data).then(
      (response) => {
        toast.success('Book Borrowed Successfully \n Need To Be Returned Within 30 Days', {
          position: 'bottom-center',
          autoClose: 4000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark',
        });
      },
      (error) => {
        console.log(error);
        toast.error('Something Went Wrong', {
          position: 'bottom-center',
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark',
        });
      }
    );
  };

  return (
    <div>
      <div className="row">
        <div className="col-md-4">
          <div className="card mb-4 custom-card">
            <Img
              src={`/images/${book.bookId}.jpeg`}
              className="card-img-top"
              alt={book.bookId}
            />
            <div className="card-body">
              <h5 className="card-title">{book.name}</h5>
              <p className="card-text">Author: {book.author}</p>
              <Button color="primary" onClick={() => handleClick(book.bookId)}>
                Borrow
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

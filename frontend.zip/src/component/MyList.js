import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Table } from "reactstrap";
import issue_book_url from "../service/IssueUrl";
import base_url from "../service/api";

export default function MyList({ book, memberUsername, bookName, update }) {
  const { id } = useParams();
  console.log(book)

  const deleteBook = (issueId) => {
    axios.delete(`${issue_book_url}/returnBook/${issueId}`).then(
      (response) => {
        toast.success("Book Returned Successfully", {
          position: 'bottom-center',
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark'
        });
        window.location.reload();
      },
      () => {
        toast.error("Return Fail", {
          position: 'bottom-center',
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          theme: 'dark'
        });
      }
    );
  };

  // const getBookFromServer = () => {
  //   axios.get(`${base_url}/getbookbyid/${books.bookId}`).then(
  //     (response) => {
  //       setBooks(response.data);


  //     }, (error) => {
  //       console.log(error);

  //     }
  //   )
  // }

  return (
    <>
      <Table striped >
        <thead>
          <tr>
            <td>Issue Id</td>
            <td>Book Id</td>
            <td>Username</td>
            {/* <td>Name</td> */}
            <td>Issued Date</td>
            <td>Return Date</td>
            <td>Action</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>{book.issueBookId}</th>
            <th>{book.bookId}</th>
            <th>{book.memberUsername}</th>
            {/* <th>{book.bookName}</th> */}
            <th style={{ color: "green" }}>{book.issueDate}</th>
            <th style={{ color: "red" }}>{book.returnDate}</th>
            <td>
              <Button
                size="sm"
                color="warning"
                onClick={() => {
                  deleteBook(book.issueBookId);
                }}
              >
                Return Book
              </Button>
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
}
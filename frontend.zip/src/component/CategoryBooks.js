import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import ShowBook from './MemberShowBookCard';


function CategoryBooks() {
  const { id, category } = useParams();
  console.log("myoutput " +id)
  console.log("my categories are "+ category)
  const [books, setBooks] = useState([]);

  useEffect(() => {
    async function fetchBooksByCategory() {
      try {
        const apiUrl = `http://localhost:5000/book/getcategory/${category}`;
        const response = await fetch(apiUrl);

        if (response.ok) {
          const data = await response.json();
          setBooks(data);
        } else {
          console.error(`Failed to fetch books for category ${category}`);
        }
      } catch (error) {
        console.error(`An error occurred while fetching books for category ${category}:`, error);
      }
    }

    fetchBooksByCategory();
  }, [category]);

  return (
    <div class="container-fluid">
      <h2>Books in {category}</h2>
      <div className="d-flex flex-wrap bd-highlight mb-3">
        {books.map((book) => (
          <ShowBook key={book.bookId} book={book} memberUsername={id} />
        ))}
      </div>
    </div>
  );
}

export default CategoryBooks;
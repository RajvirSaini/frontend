import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import { Button, Container, Form, Row, Col } from 'reactstrap';
import base_member_api from '../service/member_api';

export default function MemberSignup() {
  const navigate = useNavigate();

  const [signup, setSignup] = useState({
    firstName: '',
    lastName: '',
    email: '',
    contact: '',
    username: '',
    password: '',
    confirmPassword: '',
    passwordMatch: true,
  });

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setSignup((prevState) => ({
      ...prevState,
      [name]: value,
      passwordMatch: name === 'confirmPassword' ? prevState.password === value : prevState.passwordMatch,
    }));
  };

  const isEmailValid = (email) => {
    const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    return emailPattern.test(email);
  };

  const isPhoneNumberValid = (contact) => {
    const phonePattern = /^\d{10}$/; // Assuming 10-digit phone number
    return phonePattern.test(contact);
  };

  const handleSignup = (e) => {
    e.preventDefault();
    if (!isPhoneNumberValid(signup.contact)) {
      toast.error("Phone number entered is incorrect", {
        position: 'bottom-center',
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        theme: 'dark',
      });
    } else if (!isEmailValid(signup.email)) {
      toast.error("Invalid email format", {
        position: 'bottom-center',
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        theme: 'dark',
      });
    } else if (signup.password !== signup.confirmPassword) {
      toast.error("Passwords don't match", {
        position: 'bottom-center',
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        theme: 'dark',
      });
    } else {
      console.log('Signup form submitted:', signup);
      addMemberToServer(signup);
    }
  };

  const addMemberToServer = (data) => {
    console.log(data);
    axios
      .post(`${base_member_api}/addmember`, data)
      .then(
        (response) => {
          toast.success('Verify Your Email to Login', {
            position: 'bottom-center',
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            theme: 'dark',
          });
          navigate('/');
        },
        (error) => {
          console.log(error);
          toast.error('Something went wrong', {
            position: 'bottom-center',
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            theme: 'dark',
          });
        }
      );
  };

  return (
    <div className="limiter">
      <div className="container-login100">
        <div className="wrap-login100">
          <form className="login100-form validate-form" onSubmit={handleSignup}>
            <h1>Library Management System</h1>
            <span className="login100-form-title p-b-43">
              <br />
              Signup to continue
            </span>
            <div className="wrap-input100 validate-input" data-validate="First Name is required">
              <input
                className="input100"
                type="text"
                name="firstName"
                onChange={(e) => {
                  setSignup({ ...signup, firstName: e.target.value });
                }}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                First Name
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Last Name is required">
              <input
                className="input100"
                type="text"
                name="lastName"
                onChange={(e) => {
                  setSignup({ ...signup, lastName: e.target.value });
                }}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Last Name
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
              <input
                className="input100"
                type="email"
                name="email"
                onChange={(e) => {
                  setSignup({ ...signup, email: e.target.value });
                }}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Email
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Contact number is required">
              <input
                className="input100"
                type="text"
                name="contact"
                onChange={(e) => {
                  setSignup({ ...signup, contact: e.target.value });
                }}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Contact Number
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Username is required">
              <input
                className="input100"
                type="text"
                name="username"
                onChange={(e) => {
                  setSignup({ ...signup, username: e.target.value });
                }}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Username
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Password is required">
              <input
                className="input100"
                type="password"
                name="password"
                onChange={handlePasswordChange}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Password
                <br />
              </span>
            </div>
            <div className="wrap-input100 validate-input" data-validate="Confirm Password is required">
              <input
                className="input100"
                type="password"
                name="confirmPassword"
                onChange={handlePasswordChange}
                required
              />
              <span className="focus-input100"></span>
              <span className="label-input100">
                <br />
                Confirm Password
                <br />
              </span>
              {signup.confirmPassword !== '' && (
                <p style={{ color: signup.passwordMatch ? '#50C878' : 'red', marginTop: '5px' }}>
                  {signup.passwordMatch ? 'Passwords match' : 'Passwords do not match'}
                </p>
              )}
            </div>
            <div>
              <p style={{ color: 'red', marginTop: '60px' }}></p>
            </div>
            <div className="container-login100-form-btn">
              <button className="login100-form-btn" type="submit">
                Signup
              </button>
            </div>
            <div className="text-center p-t-46 p-b-20">
              <span className="txt2">
                Already have an account? <a href="/" className="txt3">
                  Login
                </a>
              </span>
            </div>
          </form>
          <div className="login100-more" style={{ backgroundImage: "url('images2/122a.jpg')" }}></div>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect } from "react";
import { Container, Button, Row, Col, Card, CardBody } from "reactstrap";
import Menu from './Menu';




export default function Contact() {
  useEffect(()=>{

    document.title = "Contact "
  },[]);


  return (
    <>
    <Row>
      <Col md={4} ><Menu/></Col>
      <Col>
         <Card style={{backgroundColor : '#404040' , marginTop : '15px'}}>
          <CardBody>
          <div className="mt-4 p-5 bg-light text-dark rounded text-center"  style={{backgroundColor : 'aquamarine'}}>
         <h3>Thank You For Using Our Services</h3>
         <hr/>
      
         <h5>Feel Free To Contact regarding Any Query on Below Details</h5>
         <hr/>
        
         <p> Thank you for using the Library Management System </p>
         <p> This project was done by : </p>
         
         
    </div>
          </CardBody>
         </Card>
      
      
      
      </Col>
    </Row>
    
    </>
  )
}
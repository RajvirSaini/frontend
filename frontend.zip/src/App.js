
import './App.css';
import { Button, Col, Container, Row } from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import Home from './component/AdminHome';
import Book from './component/AdminShowBookCard';
import AllBooks from './component/AllBooks';
import AddBook from './component/AddBook';
import Header from './component/Header';
import Menu from './component/Menu';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import UpdateBook from './component/UpdateBook';
import Signup from './component/MemberSignup';
import { LoginMember } from './component/LoginMember';
import MemberMenu from './component/MemberMenu';
import ViewBooksForMember from './component/ViewBooksForMember'
import { useState } from 'react';
import IssueList from './component/IssueList';
import AdminIssuedBook from './component/AdminIssuedBook';
import IssuedForUser from './component/IssuedForUser';
import SearchByCategory from './component/SearchByCategory';
import SearchByBook from './component/SearchByBook';
import Contact from './component/Contact';
import CategoryBooks from './component/CategoryBooks';
import LoginAdmin from './component/LoginAdmin';
import SearchByBookAdmin from './component/SearchByBookAdmin';






function App() {

  const btnHandle = () =>{
    toast.success("Done!",{
      position : 'top-center'
    })
  
  }
  return (
    <div>
      <BrowserRouter>
      <ToastContainer/>

<Container >
  <Row>
    <Col>
    <Routes>
    {/* <Route path='/' element = {<LoginOption/>}/> */}
    <Route path='/' element = {<LoginMember/>}/>
    <Route path='/viewbooksformember/:id' element = {<ViewBooksForMember/>}/>
    <Route path='/issuelist/:id' element = {<IssueList/>}/>
    <Route path='/searchbycategory/:id' element = {<SearchByCategory/>}/>
    <Route path='/category/:category/:id' element = {<CategoryBooks/>}/>
    <Route path='/searchbybook/:id' element = {<SearchByBook/>}/>
    <Route path='/login' element = {<LoginAdmin/>}/>
    <Route path='/membermenu/:id' element = {<MemberMenu/>}/>
    <Route path='/signup' element = {<Signup/>}/>
    <Route path='/contact' element = {<Contact/>}/>
    <Route path='/adminIssuedbooks' element = {<AdminIssuedBook/>}/>
    <Route path='/home' element = {<Home/>}/>
    <Route path = '/add-book' element = {<AddBook/>}/>
    <Route path = '/view-books' element = {<AllBooks/>}/>
    <Route path = '/issuedforusers' element = {<IssuedForUser/>}/>
    <Route path = '/update-book/:bookId' element = {<UpdateBook/>}/>
    <Route path='/searchbybookadmin' element= {<SearchByBookAdmin/>}/>
    issuedforusers
    
    </Routes>
    </Col>
  </Row>
</Container>

      
      </BrowserRouter>
    </div>
   
  );
}

export default App;


